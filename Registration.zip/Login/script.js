const signUpButton = document.getElementById('signUpButton');
const signInButton = document.getElementById('signInButton');
const signInForm = document.getElementById('signIn');
const signUpForm = document.getElementById('signup');
const notification = document.getElementById('notification');
const passwordMeter = document.getElementById('passwordMeter');
const passwordStrengthLabel = document.getElementById('passwordStrengthLabel'); // Add this line

// Event listeners for Sign In and Sign Up buttons
signUpButton.addEventListener('click', function () {
    signInForm.style.display = "none";
    signUpForm.style.display = "block";
});

signInButton.addEventListener('click', function () {
    signInForm.style.display = "block";
    signUpForm.style.display = "none";
});

// Handle notification display on load
window.onload = function () {
    if (notification.innerText) {
        notification.classList.add('show');
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000); 
    }

    // Initialize password meter and label on load
    updatePasswordMeter(0); // Set initial strength to 0
    passwordStrengthLabel.style.display = 'none'; // Hide label initially
};

// Function to calculate password strength
function calculatePasswordStrength(password) {
    let strength = 0;
    if (password.length >= 8) strength += 0.25;
    if (/[a-z]/.test(password)) strength += 0.25;
    if (/[A-Z]/.test(password)) strength += 0.25;
    if (/\d/.test(password)) strength += 0.25;
    if (/[@$!%*?&]/.test(password)) strength += 0.25;
    return strength; // return a value between 0 and 1
}

// Update password meter and label
function updatePasswordMeter(strength) {
    if (passwordMeter) {
        passwordMeter.innerHTML = `<div style="width: ${strength * 100}%; background-color: ${getMeterColor(strength)}; height: 10px;"></div>`;
    }
    updateStrengthLabel(strength); // Update the strength label
}

// Update strength label based on strength
function updateStrengthLabel(strength) {
    if (passwordStrengthLabel) {
        if (strength < 0.4) {
            passwordStrengthLabel.textContent = 'Poor';
            passwordStrengthLabel.className = 'poor'; // Add poor class for styling
        } else if (strength < 0.7) {
            passwordStrengthLabel.textContent = 'Fair';
            passwordStrengthLabel.className = 'fair'; // Add fair class for styling
        } else if (strength < 1) {
            passwordStrengthLabel.textContent = 'Good';
            passwordStrengthLabel.className = 'good'; // Add good class for styling
        } else {
            passwordStrengthLabel.textContent = 'Excellent';
            passwordStrengthLabel.className = 'excellent'; // Add excellent class for styling
        }
        passwordStrengthLabel.style.display = 'block'; // Show label when updating
    }
}

// Function to get meter color based on strength
function getMeterColor(strength) {
    if (strength < 0.4) return 'red';
    else if (strength < 0.7) return 'orange';
    else if (strength < 1) return 'blue';
    else return 'green';
}

// Add password strength event listener
const passwordInput = document.getElementById('registerPassword');
passwordInput.addEventListener('input', function() {
    const password = passwordInput.value;
    const strength = calculatePasswordStrength(password);
    updatePasswordMeter(strength);
    
    // Hide the strength label if password is empty
    if (password.length === 0) {
        passwordStrengthLabel.style.display = 'none';
    } else {
        passwordStrengthLabel.style.display = 'block'; // Ensure it shows if there's input
    }
});
