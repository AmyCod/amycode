<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register & Login</title>
    <script>
        // Create a global variable for password strength using PHP
        var passwordStrength = <?php echo json_encode($_SESSION['password_strength'] ?? 0); ?>; // Default to 0 if not set
    </script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <!-- Notification Section -->
    <div id="notification" class="notification"></div>

    <div class="container" id="signup" style="display:none;">
        <h1 class="form-title">Register</h1>
        <form method="post" action="register.php" onsubmit="return validatePassword()">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="fName" id="fName" placeholder="First Name" required>
                <label for="fName">First Name</label>
            </div>
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="lName" id="lName" placeholder="Last Name" required>
                <label for="lName">Last Name</label>
            </div>
            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" id="registerEmail" placeholder="Email" required>
                <label for="registerEmail">Email</label>
            </div>

            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" id="registerPassword" placeholder="Password" required>
                <label for="registerPassword">Password</label>
                <div id="passwordMeterContainer">
                    <div id="passwordMeter"></div>
                    <div id="passwordStrengthLabel" class="password-strength-label"></div>
                    <!-- Password strength label -->
                </div>
                <span id="passwordError" style="color:red; display:none;">Password must be at least 8 characters long,
                    include at least one uppercase letter, one lowercase letter, one number, and one special
                    character.</span>
            </div>
            <input type="submit" class="btn" value="Sign Up" name="signUp">
        </form>

        <div class="links">
            <p>Already Have Account?</p>
            <button id="signInButton">Sign In</button>
        </div>
    </div>

    <div class="container" id="signIn">
        <h1 class="form-title">Sign In</h1>
        <form method="post" action="register.php">
            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" id="loginEmail" placeholder="Email" required>
                <label for="loginEmail">Email</label>
            </div>
            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" id="loginPassword" placeholder="Password" required>
                <label for="loginPassword">Password</label>
            </div>
            <input type="submit" class="btn" value="Sign In" name="signIn">
        </form>
        <div class="links">
            <p>Don't have an account yet?</p>
            <button id="signUpButton">Sign Up</button>
        </div>
    </div>


    <!-- Password verification failed message -->
    <div id="errorMessage" class="notification" style="display: none;">
        <a href="index.php" class="exit-button"><i class="fas fa-times"></i></a>
        <p>Password verification failed. Please try again.</p>
    </div>


    <script src="script.js"></script>

    <?php
    session_start();
    // Check for registration success notification
    if (isset($_SESSION['registration_success'])) {
        echo "<script>document.getElementById('notification').innerText = '" . $_SESSION['registration_success'] . "';</script>";
        unset($_SESSION['registration_success']); // Clear the notification after displaying
    }

    // Check for password error notification
    if (isset($_SESSION['password_error'])) {
        echo "<script>document.getElementById('notification').innerText = '" . $_SESSION['password_error'] . "';</script>";
        unset($_SESSION['password_error']); // Clear the notification after displaying
    }

    // Check for email error notification
    if (isset($_SESSION['email_error'])) {
        echo "<script>document.getElementById('notification').innerText = '" . $_SESSION['email_error'] . "';</script>";
        unset($_SESSION['email_error']); // Clear the notification after displaying
    }

    // Check for password verification error notification
    if (isset($_SESSION['error'])) {
        echo "<script>document.getElementById('errorMessage').style.display = 'block';</script>";
        unset($_SESSION['error']); // Clear the error after displaying
    }
    ?>

    <script>
        function validatePassword() {
            const password = document.getElementById('registerPassword').value;
            const passwordError = document.getElementById('passwordError');
            const strongPasswordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

            if (!strongPasswordPattern.test(password)) {
                passwordError.style.display = 'block';
                return false; // Prevent form submission
            } else {
                passwordError.style.display = 'none';
                return true; // Allow form submission
            }
        }

        // Add password strength event listener
        const passwordInput = document.getElementById('registerPassword');

        passwordInput.addEventListener('input', function () {
            const password = passwordInput.value;
            passwordStrength = calculatePasswordStrength(password);
            updatePasswordMeter(passwordStrength);
        });

        function calculatePasswordStrength(password) {
            // Implement your own logic for calculating password strength
            let strength = 0;
            if (password.length >= 8) strength += 0.25;
            if (/[a-z]/.test(password)) strength += 0.25;
            if (/[A-Z]/.test(password)) strength += 0.25;
            if (/\d/.test(password)) strength += 0.25;
            if (/[@$!%*?&]/.test(password)) strength += 0.25;
            return strength; // return a value between 0 and 1
        }

        function updatePasswordMeter(strength) {
            if (passwordMeter) {
                passwordMeter.innerHTML = `<div style="width: ${strength * 100}%; background-color: ${getMeterColor(strength)}; height: 10px;"></div>`;

                // Update the password strength label
                const strengthLabel = document.getElementById('passwordStrengthLabel');
                if (strength < 0.4) {
                    strengthLabel.innerText = 'Poor';
                    strengthLabel.style.color = 'red'; // Style the label
                } else if (strength < 0.7) {
                    strengthLabel.innerText = 'Fair';
                    strengthLabel.style.color = 'orange'; // Style the label
                } else if (strength < 1) {
                    strengthLabel.innerText = 'Good';
                    strengthLabel.style.color = 'blue'; // Style the label
                } else {
                    strengthLabel.innerText = 'Excellent';
                    strengthLabel.style.color = 'green'; // Style the label
                }
            }
        }

        window.onload = function () {
            // Handle notification display
            if (notification.innerText) {
                notification.classList.add('show');
                setTimeout(() => {
                    notification.classList.remove('show');
                }, 3000);
            }

            // Access password strength and update meter
            if (passwordMeter) {
                passwordMeter.innerHTML = `<div style="width: ${passwordStrength * 100}%; background-color: ${getMeterColor(passwordStrength)}; height: 10px;"></div>`;

                // Update the password strength label
                const strengthLabel = document.getElementById('passwordStrengthLabel');
                if (passwordStrength < 0.4) {
                    strengthLabel.innerText = 'Poor';
                    strengthLabel.style.color = 'red'; // Style the label
                } else if (passwordStrength < 0.7) {
                    strengthLabel.innerText = 'Fair';
                    strengthLabel.style.color = 'orange'; // Style the label
                } else if (passwordStrength < 1) {
                    strengthLabel.innerText = 'Good';
                    strengthLabel.style.color = 'blue'; // Style the label
                } else {
                    strengthLabel.innerText = 'Excellent';
                    strengthLabel.style.color = 'green'; // Style the label
                }
            }
        };

        // Function to get meter color based on strength
        function getMeterColor(strength) {
            if (strength < 0.4) return 'red';
            else if (strength < 0.7) return 'orange';
            else if (strength < 1) return 'blue';
            else return 'green';
        }
    </script>
</body>

</html>