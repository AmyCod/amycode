<?php
session_start();
include("connect.php");

// Check if session is active, if not, redirect to login
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

// Function to display password information
function displayPasswordInfo($password, $pepper) {
    // Salt can be a random string; you can set it based on your application's requirements.
    $salt = bin2hex(random_bytes(16)); // Generate a random salt
    $saltedPassword = $password . $salt; // Salted Password
    $hashedSaltedPassword = password_hash($saltedPassword, PASSWORD_BCRYPT); // Hashed (Salted) Password
    $hashedSaltedPepperPassword = password_hash($saltedPassword . $pepper, PASSWORD_BCRYPT); // Hashed (Salted + Pepper) Password

    // Display the passwords
    echo "<p><strong>Plain Password:</strong> " . htmlspecialchars($password) . "</p>";
    echo "<p><strong>Salted Password:</strong> " . htmlspecialchars($saltedPassword) . "</p>";
    echo "<p><strong>Hashed (Salted) Password:</strong> " . htmlspecialchars($hashedSaltedPassword) . "</p>";
    echo "<p><strong>Hashed (Salted + Pepper) Password:</strong> " . htmlspecialchars($hashedSaltedPepperPassword) . "</p>";
    echo "<p><strong>Stored Hashed Password:</strong> " . htmlspecialchars($hashedSaltedPepperPassword) . "</p>"; // This will be the same as the previous one since it's the one you store
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self'; style-src 'self';">
</head>
<body>
    <div style="text-align:center; padding:15%;">
      <p style="font-size:50px; font-weight:bold;">
       Hello  
       <?php 
       if (isset($_SESSION['email'])) {
           $email = $_SESSION['email'];
           $stmt = $conn->prepare("SELECT firstName, lastName FROM users WHERE email = ?");
           $stmt->bind_param("s", $email);
           $stmt->execute();
           $result = $stmt->get_result();
           
           if ($result->num_rows > 0) {
               $row = $result->fetch_assoc();
               echo htmlspecialchars($row['firstName'] . ' ' . $row['lastName']);  // Escape for safety
           }
           $stmt->close();
       }
       ?>
       :)
      </p>

      <?php
      // Get the plain password from session
      $plainPassword = isset($_SESSION['plain_password']) ? $_SESSION['plain_password'] : ''; // Retrieve the password from session
      $pepper = 'someRandomPepperString'; // Same pepper as used in register.php

      // Call function to display password information
      displayPasswordInfo($plainPassword, $pepper);
      ?>

      <a href="logout.php">Logout</a>
    </div>
</body>
</html>
