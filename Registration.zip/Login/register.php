
<?php
include 'connect.php';

// Define a pepper (store this in a secure location like an environment variable)
$pepper = 'someRandomPepperString'; // Replace this with your actual pepper or use getenv('PEPPER')

// Function to validate password strength
function isPasswordStrong($password) {
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password);
}

// Register new user
if (isset($_POST['signUp'])) {
    $firstName = $_POST['fName'];
    $lastName = $_POST['lName'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate password strength
    if (!isPasswordStrong($password)) {
        // Set error message in session to show on the front-end
        session_start();
        $_SESSION['password_error'] = "Password must be at least 8 characters long, include at least one uppercase letter, one lowercase letter, one number, and one special character.";
        header("Location: index.php"); // Redirect back to the registration page
        exit();
    }

    // Add pepper to the password
    $passwordWithPepper = $password . $pepper;

    // Hash the password with bcrypt (which handles salting automatically)
    $hashedPassword = password_hash($passwordWithPepper, PASSWORD_BCRYPT);

    // Check if the email already exists
    $checkEmail = "SELECT * FROM users WHERE email=?";
    $stmt = $conn->prepare($checkEmail);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        session_start();
        $_SESSION['email_error'] = "Email Address Already Exists!";
        header("Location: index.php");
        exit();
    } else {
        // Insert new user with hashed password
        $insertQuery = "INSERT INTO users(firstName, lastName, email, password) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param("ssss", $firstName, $lastName, $email, $hashedPassword);

        if ($stmt->execute()) {
            session_start();
            $_SESSION['registration_success'] = "Account created successfully!"; // Set the session variable
            header("Location: index.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    }
    $stmt->close(); // Close statement
}

// Login user
if (isset($_POST['signIn'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Add pepper to the password for verification
    $passwordWithPepper = $password . $pepper;

    // Fetch the hashed password from the database
    $sql = "SELECT password FROM users WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($hashedPassword);
        $stmt->fetch();

        // Verify the password
        if (password_verify($passwordWithPepper, $hashedPassword)) {
            session_start();
            $_SESSION['email'] = $email;
            $_SESSION['plain_password'] = $password; // Store the plain password in the session
            header("Location: homepage.php"); // Redirect to homepage after login
            exit();
        } else {
            session_start();
            $_SESSION['error'] = "Password verification failed."; // Set error in session
            header("Location: index.php"); // Redirect back to login page
            exit();
        }
    } else {
        echo "Email not found.";
    }

    $stmt->close(); // Close statement
}

